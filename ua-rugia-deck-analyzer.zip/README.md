# UA 牌組分析 — Rugia 自動匯入版

## 檔案
- `index.html` — GitHub Pages 網站
- `worker.js` — Cloudflare Worker，負責跨網域取得 Rugia Creation 頁面

## 使用方式

1. 把 `index.html` 上傳到 GitHub repository。
2. 用 Cloudflare Workers 建立一個 Worker，把 `worker.js` 的內容貼進去並部署。
3. 複製 Worker URL，例如：
   `https://ua-rugia-proxy.example.workers.dev`
4. 在網站左側「Rugia 自動抓取」輸入 Worker URL，按「儲存 Proxy」。
5. 貼上 Rugia 的 `deckEdit?...&Deck=...` 連結。
6. 按「分析並儲存牌組」。
7. 網站會逐張取得：
   - 卡號
   - 稀有度
   - 卡名
   - Rugia 的繁體中文效果
8. 點擊任何卡片，右側會顯示完整效果。
9. 單張卡也可以按「從 Rugia 更新」。

## 重要
GitHub Pages 本身是靜態網站。瀏覽器直接 `fetch(rugiacreation.com)` 可能受到 CORS 限制，因此推薦使用 Cloudflare Worker。
